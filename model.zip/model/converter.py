import os
from keras.models import load_model
import tensorflow as tf

model = load_model("best_model.h5")

converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

print("Model converted successfully.")

output_dir = "converted"
os.makedirs(output_dir, exist_ok=True)

output_path = os.path.join(output_dir, "model.tflite")
with open(output_path, "wb") as f:
    f.write(tflite_model)

print(f"Model saved to {output_path}")
